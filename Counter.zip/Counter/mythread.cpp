#include "mythread.h"
#include <QDebug>
#include<QMutex>

mythread::mythread(QObject *parent, bool b) :
    QThread(parent), Stop(b)
{
}

// run() will be called when a thread starts
void mythread::run()
{
    count ;
    for(; count <= 100; count ++)
    {
        QMutex mutex;
        // prevent other threads from changing the "Stop" value
        mutex.lock();
        if(this->Stop) break;
        mutex.unlock();

        // emit the signal for the count label
        emit valueChanged(count);

        // slowdown the count change, msec
        this->msleep(500);
    }
}
