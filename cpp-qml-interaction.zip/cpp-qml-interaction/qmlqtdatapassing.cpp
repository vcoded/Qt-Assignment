#include "qmlqtdatapassing.h"
#include <QString>
#include <QDebug>


QmlQtDataPassing::QmlQtDataPassing(QObject *parent) : QObject(parent)
{

}

void QmlQtDataPassing :: hello_Slot()
{
    QString new_Text = "Someone Say hello !!";
    emit hello_signal(new_Text);

    qDebug() << new_Text;
}
