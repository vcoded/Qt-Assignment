#include "qmlqtdatapass.h"

QmlQtDataPass::QmlQtDataPass()
{

}
