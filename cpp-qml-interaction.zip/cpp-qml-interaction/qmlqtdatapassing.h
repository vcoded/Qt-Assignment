#ifndef QMLQTDATAPASSING_H
#define QMLQTDATAPASSING_H

#include <QObject>

class QmlQtDataPassing : public QObject
{
    Q_OBJECT
public:
    explicit QmlQtDataPassing(QObject *parent = nullptr);

signals:
    void hello_signal(const QString &text);

public slots:
    void hello_Slot();
};

#endif // QMLQTDATAPASSING_H
