#ifndef QMLQTDATAPASS_H
#define QMLQTDATAPASS_H

#include <QObject>

class QmlQtDataPass
{
public:
    QmlQtDataPass();
};

#endif // QMLQTDATAPASS_H
