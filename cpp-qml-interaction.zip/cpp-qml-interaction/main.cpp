#include <QApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>

#include "qmlqtdatapassing.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    QQmlApplicationEngine engine;

    QmlQtDataPassing QmlQbj;

    // Load the QML and set the Context
    engine.load(QUrl(QStringLiteral("qrc:/main.qml")));
    engine.rootContext()->setContextProperty("qmlqtdatapassing",&QmlQbj);

    return app.exec();
}
